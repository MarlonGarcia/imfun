# __init__.py

from .__main__ import *

# Version of the image-functions package
__version__ = "0.1.6"