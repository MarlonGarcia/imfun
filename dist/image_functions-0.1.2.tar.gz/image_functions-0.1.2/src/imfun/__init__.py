# __init__.py

from .__main__ import *

# Version of the hyperspectral-imaging package
__version__ = "0.1.2"