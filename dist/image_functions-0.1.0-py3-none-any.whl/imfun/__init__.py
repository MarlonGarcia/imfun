# __init__.py

from .__main__ import *